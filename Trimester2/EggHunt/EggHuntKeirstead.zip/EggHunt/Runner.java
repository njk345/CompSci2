
/**
 * creates an instance of the KidsGame class and runs it.
 * 
 * Nick Keirstead
 * Started: 1/23/15
 * Completed: 1/23/15
 */

public class Runner {
    public static void main (String[] args) throws InterruptedException {
            new EggHunt().start();
    }
}
